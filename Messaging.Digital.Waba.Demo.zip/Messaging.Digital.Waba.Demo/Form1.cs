﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Windows.Forms;

namespace Messaging.Digital.Waba.Demo
{
    public partial class Form1 : Form
    {

        HttpClient httpClient = new HttpClient() { BaseAddress = new Uri($"{WabaEndPoints.MdBaseUrl}/{WabaEndPoints.MdEndPointVersion}/") };
        string MdAuthToken; 

        public Form1()
        {
            InitializeComponent();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0 && string.IsNullOrEmpty(MdAuthToken))
            {
                MessageBox.Show("Get Auth Token First");
                tabControl1.SelectedIndex = 0;
            }
        }

        private async void btnAuthToken_Click(object sender, EventArgs e)
        {
            if (txtAuthTokenValidityMinutes.Text == "") txtAuthTokenValidityMinutes.Text = "0";
            MdAuthTokenReq authTokenReq = new MdAuthTokenReq() 
            {
                 UserId = txtUserId.Text,
                 Password = txtPassword.Text,
                 AuthTokenValidityMins = Convert.ToUInt64(txtAuthTokenValidityMinutes.Text)
            };
            try
            {
                MdTxnResp mdTxnResp = await httpClient.GetMdAuthToken(authTokenReq);
                if (mdTxnResp.isSuccess)
                {
                    MdAuthToken = mdTxnResp.txnOutcome;
                    txtResponse.Text = "Auth Token Stored internally in Static Variable." + Environment.NewLine;
                }
                txtResponse.Text += JsonSerializer.Serialize(mdTxnResp);
            }
            catch (Exception Ex)
            {
                txtResponse.Text = Ex.Message;
            }
        }

        private async void btnSendTextMsg_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(MdAuthToken) || string.IsNullOrEmpty(txtPhoneNoId.Text) || string.IsNullOrEmpty(txtToMobileNo.Text))
            {
                MessageBox.Show("Either AuthToken not taken or PhoneNo Id and To Mobile No. is required");
                return;
            }
            try
            {
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", MdAuthToken);
                MdWabaMessagesResponse mdWabaMsgResp = await httpClient.SendWabaTextMsg(Convert.ToUInt64(txtPhoneNoId.Text), txtToMobileNo.Text, rtSendTextMsgMessageText.Text);
                txtResponse.Text = JsonSerializer.Serialize(mdWabaMsgResp);
            }
            catch (MdWabaException waEx)
            {
                txtResponse.Text = waEx.Message + Environment.NewLine + JsonSerializer.Serialize(waEx.WabaErrResp);
            }
        }

        private void btnBrowseSendMedia_Click(object sender, EventArgs e)
        {
            var dlg = new OpenFileDialog();
            if (dlg.ShowDialog() != DialogResult.OK)
                return;

            txtUploadAndSendMediaFileName.Text = dlg.FileName;

        }
        private async void btnUploadAndSendMedia_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(MdAuthToken) || string.IsNullOrEmpty(txtPhoneNoId.Text) || string.IsNullOrEmpty(txtToMobileNo.Text))
            {
                MessageBox.Show("Either AuthToken not taken or PhoneNo Id and To Mobile No. is required");
                return;
            }
            try
            {
                byte[] MediaBytes = File.ReadAllBytes(txtUploadAndSendMediaFileName.Text);
                string[] FileNameParts = txtUploadAndSendMediaFileName.Text.Split('\\');
                string strFileName = FileNameParts[FileNameParts.Length - 1];
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", MdAuthToken);
                MdWabaMessagesResponse mdWabaMsgResp = await httpClient.UploadAndSendWabaMediaMsg(Convert.ToUInt64(txtPhoneNoId.Text), txtToMobileNo.Text, MediaBytes, strFileName, "Messaging.Digital.DEMO");
                txtResponse.Text = JsonSerializer.Serialize(mdWabaMsgResp);
            }
            catch (MdWabaException waEx)
            {
                txtResponse.Text = waEx.Message + Environment.NewLine + JsonSerializer.Serialize(waEx.WabaErrResp);
            }
            catch (Exception ex) 
            {
                txtResponse.Text = ex.Message;
            }
        }
        private async void btnSendMediaByUrl_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(MdAuthToken) || string.IsNullOrEmpty(txtPhoneNoId.Text) || string.IsNullOrEmpty(txtToMobileNo.Text))
            {
                MessageBox.Show("Either AuthToken not taken or PhoneNo Id and To Mobile No. is required");
                return;
            }
            try
            {
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", MdAuthToken);
                MdWabaMessagesResponse mdWabaMsgResp = await httpClient.SendWabaMediaMsgByUrl(Convert.ToUInt64(txtPhoneNoId.Text), txtToMobileNo.Text, txtMediaUrl.Text, "Messaging.Digital.DEMO");
                txtResponse.Text = JsonSerializer.Serialize(mdWabaMsgResp);
            }
            catch (MdWabaException waEx)
            {
                txtResponse.Text = waEx.Message + Environment.NewLine + JsonSerializer.Serialize(waEx.WabaErrResp);
            }
            catch (Exception ex)
            {
                txtResponse.Text = ex.Message;
            }
        }

        private async void btnSendTextTmplMsg_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(MdAuthToken) || string.IsNullOrEmpty(txtPhoneNoId.Text) || string.IsNullOrEmpty(txtToMobileNo.Text))
            {
                MessageBox.Show("Either AuthToken not taken or PhoneNo Id and To Mobile No. is required");
                return;
            }
            try
            {
                string[] TextTmplParms = null;
                if(!string.IsNullOrEmpty(txtSendTmplParms.Text))
                    TextTmplParms = txtSendTmplParms.Text.Split(',');
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", MdAuthToken);
                MdWabaMessagesResponse mdWabaMsgResp = await httpClient.SendWabaTextTemplateMsg(Convert.ToUInt64(txtPhoneNoId.Text), txtToMobileNo.Text, txtTmplName.Text, txtTmplLanguage.Text, TextTmplParms);
                txtResponse.Text = JsonSerializer.Serialize(mdWabaMsgResp);
            }
            catch (MdWabaException waEx)
            {
                txtResponse.Text = waEx.Message + Environment.NewLine + JsonSerializer.Serialize(waEx.WabaErrResp);
            }
        }
        private void btnBrowseSendMediaTmpl_Click(object sender, EventArgs e)
        {
            var dlg = new OpenFileDialog();
            if (dlg.ShowDialog() != DialogResult.OK)
                return;

            txtUploadAndSendMediaUsingTmplFileName.Text = dlg.FileName;
        }

        private async void btnUploadAndSendMediaUsingTemplate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(MdAuthToken) || string.IsNullOrEmpty(txtPhoneNoId.Text) || string.IsNullOrEmpty(txtToMobileNo.Text))
            {
                MessageBox.Show("Either AuthToken not taken or PhoneNo Id and To Mobile No. is required");
                return;
            }
            try
            {
                byte[] MediaBytes = File.ReadAllBytes(txtUploadAndSendMediaUsingTmplFileName.Text);
                string[] FileNameParts = txtUploadAndSendMediaUsingTmplFileName.Text.Split('\\');
                string strFileName = FileNameParts[FileNameParts.Length - 1];
                string[] MediaTmplParms = null;
                if (!string.IsNullOrEmpty(txtSendMediaTmplParms.Text))
                    MediaTmplParms = txtSendMediaTmplParms.Text.Split(',');

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", MdAuthToken);
                MdWabaMessagesResponse mdWabaMsgResp = await httpClient.UploadAndSendWabaMediaTemplateMsg(Convert.ToUInt64(txtPhoneNoId.Text), txtToMobileNo.Text, MediaBytes, strFileName, txtMediaTmplName.Text, txtMediaTmplLanguage.Text, MediaTmplParms);
                txtResponse.Text = JsonSerializer.Serialize(mdWabaMsgResp);
            }
            catch (MdWabaException waEx)
            {
                txtResponse.Text = waEx.Message + Environment.NewLine + JsonSerializer.Serialize(waEx.WabaErrResp);
            }
        }

    }
}
