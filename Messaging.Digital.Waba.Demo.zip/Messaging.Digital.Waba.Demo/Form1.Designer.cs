﻿namespace Messaging.Digital.Waba.Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtResponse = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtToMobileNo = new System.Windows.Forms.TextBox();
            this.lblToMobileNo = new System.Windows.Forms.Label();
            this.txtPhoneNoId = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnAuthToken = new System.Windows.Forms.Button();
            this.txtAuthTokenValidityMinutes = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtUserId = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSendTextMsg = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.rtSendTextMsgMessageText = new System.Windows.Forms.RichTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnSendMediaByUrl = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.txtMediaUrl = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtUploadAndSendMediaFileName = new System.Windows.Forms.TextBox();
            this.btnBrowseSendMedia = new System.Windows.Forms.Button();
            this.btnUploadAndSendMedia = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.txtSendTmplParms = new System.Windows.Forms.TextBox();
            this.txtTmplLanguage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTmplName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSendTextTmplMsg = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtSendMediaTmplParms = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtUploadAndSendMediaUsingTmplFileName = new System.Windows.Forms.TextBox();
            this.btnBrowseSendMediaTmpl = new System.Windows.Forms.Button();
            this.txtMediaTmplLanguage = new System.Windows.Forms.TextBox();
            this.lblLanguage = new System.Windows.Forms.Label();
            this.txtMediaTmplName = new System.Windows.Forms.TextBox();
            this.lblTemplateName = new System.Windows.Forms.Label();
            this.lblMsgText = new System.Windows.Forms.Label();
            this.btnUploadAndSendMediaUsingTemplate = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtResponse);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 818);
            this.panel1.Margin = new System.Windows.Forms.Padding(6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1178, 302);
            this.panel1.TabIndex = 16;
            // 
            // txtResponse
            // 
            this.txtResponse.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtResponse.Location = new System.Drawing.Point(0, 37);
            this.txtResponse.Margin = new System.Windows.Forms.Padding(6);
            this.txtResponse.Multiline = true;
            this.txtResponse.Name = "txtResponse";
            this.txtResponse.Size = new System.Drawing.Size(1178, 265);
            this.txtResponse.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 6);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 25);
            this.label2.TabIndex = 34;
            this.label2.Text = "Response";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1178, 79);
            this.panel2.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(341, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(496, 32);
            this.label3.TabIndex = 35;
            this.label3.Text = "Messaging.Digital WABA API Demo";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(771, 79);
            this.panel3.Margin = new System.Windows.Forms.Padding(6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(407, 739);
            this.panel3.TabIndex = 18;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtToMobileNo);
            this.panel4.Controls.Add(this.lblToMobileNo);
            this.panel4.Controls.Add(this.txtPhoneNoId);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 79);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(771, 109);
            this.panel4.TabIndex = 19;
            // 
            // txtToMobileNo
            // 
            this.txtToMobileNo.Location = new System.Drawing.Point(224, 55);
            this.txtToMobileNo.Margin = new System.Windows.Forms.Padding(6);
            this.txtToMobileNo.Name = "txtToMobileNo";
            this.txtToMobileNo.Size = new System.Drawing.Size(371, 29);
            this.txtToMobileNo.TabIndex = 44;
            // 
            // lblToMobileNo
            // 
            this.lblToMobileNo.AutoSize = true;
            this.lblToMobileNo.Location = new System.Drawing.Point(56, 61);
            this.lblToMobileNo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblToMobileNo.Name = "lblToMobileNo";
            this.lblToMobileNo.Size = new System.Drawing.Size(129, 25);
            this.lblToMobileNo.TabIndex = 43;
            this.lblToMobileNo.Text = "To Mobile No";
            // 
            // txtPhoneNoId
            // 
            this.txtPhoneNoId.Location = new System.Drawing.Point(224, 9);
            this.txtPhoneNoId.Margin = new System.Windows.Forms.Padding(6);
            this.txtPhoneNoId.Name = "txtPhoneNoId";
            this.txtPhoneNoId.Size = new System.Drawing.Size(371, 29);
            this.txtPhoneNoId.TabIndex = 42;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(56, 14);
            this.label12.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 25);
            this.label12.TabIndex = 41;
            this.label12.Text = "Phone No Id";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tabControl1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 188);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(768, 630);
            this.panel5.TabIndex = 20;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(768, 630);
            this.tabControl1.TabIndex = 17;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.btnAuthToken);
            this.tabPage5.Controls.Add(this.txtAuthTokenValidityMinutes);
            this.tabPage5.Controls.Add(this.txtPassword);
            this.tabPage5.Controls.Add(this.label11);
            this.tabPage5.Controls.Add(this.txtUserId);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Location = new System.Drawing.Point(4, 33);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(760, 593);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "AuthToken";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // btnAuthToken
            // 
            this.btnAuthToken.Location = new System.Drawing.Point(122, 263);
            this.btnAuthToken.Margin = new System.Windows.Forms.Padding(6);
            this.btnAuthToken.Name = "btnAuthToken";
            this.btnAuthToken.Size = new System.Drawing.Size(394, 42);
            this.btnAuthToken.TabIndex = 52;
            this.btnAuthToken.Text = "Get Messaging.Digital AuthToken";
            this.btnAuthToken.UseVisualStyleBackColor = true;
            this.btnAuthToken.Click += new System.EventHandler(this.btnAuthToken_Click);
            // 
            // txtAuthTokenValidityMinutes
            // 
            this.txtAuthTokenValidityMinutes.Location = new System.Drawing.Point(274, 198);
            this.txtAuthTokenValidityMinutes.Margin = new System.Windows.Forms.Padding(6);
            this.txtAuthTokenValidityMinutes.Name = "txtAuthTokenValidityMinutes";
            this.txtAuthTokenValidityMinutes.Size = new System.Drawing.Size(371, 29);
            this.txtAuthTokenValidityMinutes.TabIndex = 51;
            this.txtAuthTokenValidityMinutes.Text = "0";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(274, 105);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(6);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(371, 29);
            this.txtPassword.TabIndex = 50;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(65, 109);
            this.label11.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 25);
            this.label11.TabIndex = 49;
            this.label11.Text = "Password";
            // 
            // txtUserId
            // 
            this.txtUserId.Location = new System.Drawing.Point(274, 52);
            this.txtUserId.Margin = new System.Windows.Forms.Padding(6);
            this.txtUserId.Name = "txtUserId";
            this.txtUserId.Size = new System.Drawing.Size(371, 29);
            this.txtUserId.TabIndex = 48;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(65, 52);
            this.label13.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(197, 25);
            this.label13.TabIndex = 47;
            this.label13.Text = "User Name (eMail Id)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(65, 167);
            this.label14.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(440, 25);
            this.label14.TabIndex = 46;
            this.label14.Text = "Auth Token Validity Minutes (0 for default validity)";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.btnSendTextMsg);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.rtSendTextMsgMessageText);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Location = new System.Drawing.Point(4, 33);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(6);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(6);
            this.tabPage2.Size = new System.Drawing.Size(760, 544);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Sample 1";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(98, 19);
            this.label8.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(358, 29);
            this.label8.TabIndex = 40;
            this.label8.Text = "Send (Service) Text Message";
            // 
            // btnSendTextMsg
            // 
            this.btnSendTextMsg.Location = new System.Drawing.Point(88, 252);
            this.btnSendTextMsg.Margin = new System.Windows.Forms.Padding(6);
            this.btnSendTextMsg.Name = "btnSendTextMsg";
            this.btnSendTextMsg.Size = new System.Drawing.Size(394, 42);
            this.btnSendTextMsg.TabIndex = 39;
            this.btnSendTextMsg.Text = "Send Waba Text Message";
            this.btnSendTextMsg.UseVisualStyleBackColor = true;
            this.btnSendTextMsg.Click += new System.EventHandler(this.btnSendTextMsg_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 64);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 25);
            this.label4.TabIndex = 38;
            this.label4.Text = "Message";
            // 
            // rtSendTextMsgMessageText
            // 
            this.rtSendTextMsgMessageText.Location = new System.Drawing.Point(12, 95);
            this.rtSendTextMsgMessageText.Margin = new System.Windows.Forms.Padding(6);
            this.rtSendTextMsgMessageText.Name = "rtSendTextMsgMessageText";
            this.rtSendTextMsgMessageText.Size = new System.Drawing.Size(534, 136);
            this.rtSendTextMsgMessageText.TabIndex = 37;
            this.rtSendTextMsgMessageText.Text = "";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(75, 726);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(394, 42);
            this.button2.TabIndex = 32;
            this.button2.Text = "Upload And Send Media Using Template";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnSendMediaByUrl);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.txtMediaUrl);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.txtUploadAndSendMediaFileName);
            this.tabPage3.Controls.Add(this.btnBrowseSendMedia);
            this.tabPage3.Controls.Add(this.btnUploadAndSendMedia);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Location = new System.Drawing.Point(4, 33);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(6);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(6);
            this.tabPage3.Size = new System.Drawing.Size(760, 593);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Sample 2";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnSendMediaByUrl
            // 
            this.btnSendMediaByUrl.Location = new System.Drawing.Point(146, 312);
            this.btnSendMediaByUrl.Margin = new System.Windows.Forms.Padding(6);
            this.btnSendMediaByUrl.Name = "btnSendMediaByUrl";
            this.btnSendMediaByUrl.Size = new System.Drawing.Size(394, 42);
            this.btnSendMediaByUrl.TabIndex = 49;
            this.btnSendMediaByUrl.Text = "Send Media Message By Url";
            this.btnSendMediaByUrl.UseVisualStyleBackColor = true;
            this.btnSendMediaByUrl.Click += new System.EventHandler(this.btnSendMediaByUrl_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(110, 254);
            this.label17.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 25);
            this.label17.TabIndex = 48;
            this.label17.Text = "Url";
            // 
            // txtMediaUrl
            // 
            this.txtMediaUrl.Location = new System.Drawing.Point(158, 254);
            this.txtMediaUrl.Margin = new System.Windows.Forms.Padding(6);
            this.txtMediaUrl.Name = "txtMediaUrl";
            this.txtMediaUrl.Size = new System.Drawing.Size(406, 29);
            this.txtMediaUrl.TabIndex = 47;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(4, 182);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(757, 2);
            this.label16.TabIndex = 46;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(110, 196);
            this.label15.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(454, 29);
            this.label15.TabIndex = 45;
            this.label15.Text = "Send (Service) Media Message by Url";
            // 
            // txtUploadAndSendMediaFileName
            // 
            this.txtUploadAndSendMediaFileName.Location = new System.Drawing.Point(210, 69);
            this.txtUploadAndSendMediaFileName.Margin = new System.Windows.Forms.Padding(6);
            this.txtUploadAndSendMediaFileName.Name = "txtUploadAndSendMediaFileName";
            this.txtUploadAndSendMediaFileName.Size = new System.Drawing.Size(371, 29);
            this.txtUploadAndSendMediaFileName.TabIndex = 44;
            // 
            // btnBrowseSendMedia
            // 
            this.btnBrowseSendMedia.Location = new System.Drawing.Point(47, 65);
            this.btnBrowseSendMedia.Margin = new System.Windows.Forms.Padding(6);
            this.btnBrowseSendMedia.Name = "btnBrowseSendMedia";
            this.btnBrowseSendMedia.Size = new System.Drawing.Size(139, 42);
            this.btnBrowseSendMedia.TabIndex = 43;
            this.btnBrowseSendMedia.Text = "Browse";
            this.btnBrowseSendMedia.UseVisualStyleBackColor = true;
            this.btnBrowseSendMedia.Click += new System.EventHandler(this.btnBrowseSendMedia_Click);
            // 
            // btnUploadAndSendMedia
            // 
            this.btnUploadAndSendMedia.Location = new System.Drawing.Point(125, 119);
            this.btnUploadAndSendMedia.Margin = new System.Windows.Forms.Padding(6);
            this.btnUploadAndSendMedia.Name = "btnUploadAndSendMedia";
            this.btnUploadAndSendMedia.Size = new System.Drawing.Size(394, 42);
            this.btnUploadAndSendMedia.TabIndex = 38;
            this.btnUploadAndSendMedia.Text = "Upload and Send Media Message";
            this.btnUploadAndSendMedia.UseVisualStyleBackColor = true;
            this.btnUploadAndSendMedia.Click += new System.EventHandler(this.btnUploadAndSendMedia_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(71, 18);
            this.label9.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(520, 29);
            this.label9.TabIndex = 37;
            this.label9.Text = "Upload Media and Send (Service) Message";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.txtSendTmplParms);
            this.tabPage4.Controls.Add(this.txtTmplLanguage);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Controls.Add(this.txtTmplName);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.btnSendTextTmplMsg);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Location = new System.Drawing.Point(4, 33);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(760, 544);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Sample 3";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // txtSendTmplParms
            // 
            this.txtSendTmplParms.Location = new System.Drawing.Point(279, 177);
            this.txtSendTmplParms.Margin = new System.Windows.Forms.Padding(6);
            this.txtSendTmplParms.Name = "txtSendTmplParms";
            this.txtSendTmplParms.Size = new System.Drawing.Size(371, 29);
            this.txtSendTmplParms.TabIndex = 45;
            // 
            // txtTmplLanguage
            // 
            this.txtTmplLanguage.Location = new System.Drawing.Point(279, 118);
            this.txtTmplLanguage.Margin = new System.Windows.Forms.Padding(6);
            this.txtTmplLanguage.Name = "txtTmplLanguage";
            this.txtTmplLanguage.Size = new System.Drawing.Size(371, 29);
            this.txtTmplLanguage.TabIndex = 44;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(111, 123);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 25);
            this.label1.TabIndex = 43;
            this.label1.Text = "Language";
            // 
            // txtTmplName
            // 
            this.txtTmplName.Location = new System.Drawing.Point(279, 60);
            this.txtTmplName.Margin = new System.Windows.Forms.Padding(6);
            this.txtTmplName.Name = "txtTmplName";
            this.txtTmplName.Size = new System.Drawing.Size(371, 29);
            this.txtTmplName.TabIndex = 42;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(111, 66);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 25);
            this.label5.TabIndex = 41;
            this.label5.Text = "TemplateName";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(111, 181);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(174, 25);
            this.label6.TabIndex = 40;
            this.label6.Text = "Parameters (CSV)";
            // 
            // btnSendTextTmplMsg
            // 
            this.btnSendTextTmplMsg.Location = new System.Drawing.Point(197, 258);
            this.btnSendTextTmplMsg.Margin = new System.Windows.Forms.Padding(6);
            this.btnSendTextTmplMsg.Name = "btnSendTextTmplMsg";
            this.btnSendTextTmplMsg.Size = new System.Drawing.Size(394, 42);
            this.btnSendTextTmplMsg.TabIndex = 39;
            this.btnSendTextTmplMsg.Text = "Send Template Text Message ";
            this.btnSendTextTmplMsg.UseVisualStyleBackColor = true;
            this.btnSendTextTmplMsg.Click += new System.EventHandler(this.btnSendTextTmplMsg_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(95, 20);
            this.label10.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(363, 29);
            this.label10.TabIndex = 38;
            this.label10.Text = "Send Template Text Message";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txtSendMediaTmplParms);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.txtUploadAndSendMediaUsingTmplFileName);
            this.tabPage1.Controls.Add(this.btnBrowseSendMediaTmpl);
            this.tabPage1.Controls.Add(this.txtMediaTmplLanguage);
            this.tabPage1.Controls.Add(this.lblLanguage);
            this.tabPage1.Controls.Add(this.txtMediaTmplName);
            this.tabPage1.Controls.Add(this.lblTemplateName);
            this.tabPage1.Controls.Add(this.lblMsgText);
            this.tabPage1.Controls.Add(this.btnUploadAndSendMediaUsingTemplate);
            this.tabPage1.Location = new System.Drawing.Point(4, 33);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(6);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(6);
            this.tabPage1.Size = new System.Drawing.Size(760, 593);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sample 4";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtSendMediaTmplParms
            // 
            this.txtSendMediaTmplParms.Location = new System.Drawing.Point(196, 231);
            this.txtSendMediaTmplParms.Margin = new System.Windows.Forms.Padding(6);
            this.txtSendMediaTmplParms.Name = "txtSendMediaTmplParms";
            this.txtSendMediaTmplParms.Size = new System.Drawing.Size(371, 29);
            this.txtSendMediaTmplParms.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(61, 11);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(486, 29);
            this.label7.TabIndex = 36;
            this.label7.Text = "Upload and Send Media Using Template";
            // 
            // txtUploadAndSendMediaUsingTmplFileName
            // 
            this.txtUploadAndSendMediaUsingTmplFileName.Location = new System.Drawing.Point(196, 180);
            this.txtUploadAndSendMediaUsingTmplFileName.Margin = new System.Windows.Forms.Padding(6);
            this.txtUploadAndSendMediaUsingTmplFileName.Name = "txtUploadAndSendMediaUsingTmplFileName";
            this.txtUploadAndSendMediaUsingTmplFileName.Size = new System.Drawing.Size(371, 29);
            this.txtUploadAndSendMediaUsingTmplFileName.TabIndex = 29;
            // 
            // btnBrowseSendMediaTmpl
            // 
            this.btnBrowseSendMediaTmpl.Location = new System.Drawing.Point(33, 176);
            this.btnBrowseSendMediaTmpl.Margin = new System.Windows.Forms.Padding(6);
            this.btnBrowseSendMediaTmpl.Name = "btnBrowseSendMediaTmpl";
            this.btnBrowseSendMediaTmpl.Size = new System.Drawing.Size(139, 42);
            this.btnBrowseSendMediaTmpl.TabIndex = 28;
            this.btnBrowseSendMediaTmpl.Text = "Browse";
            this.btnBrowseSendMediaTmpl.UseVisualStyleBackColor = true;
            this.btnBrowseSendMediaTmpl.Click += new System.EventHandler(this.btnBrowseSendMediaTmpl_Click);
            // 
            // txtMediaTmplLanguage
            // 
            this.txtMediaTmplLanguage.Location = new System.Drawing.Point(196, 119);
            this.txtMediaTmplLanguage.Margin = new System.Windows.Forms.Padding(6);
            this.txtMediaTmplLanguage.Name = "txtMediaTmplLanguage";
            this.txtMediaTmplLanguage.Size = new System.Drawing.Size(371, 29);
            this.txtMediaTmplLanguage.TabIndex = 27;
            // 
            // lblLanguage
            // 
            this.lblLanguage.AutoSize = true;
            this.lblLanguage.Location = new System.Drawing.Point(28, 124);
            this.lblLanguage.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblLanguage.Name = "lblLanguage";
            this.lblLanguage.Size = new System.Drawing.Size(100, 25);
            this.lblLanguage.TabIndex = 26;
            this.lblLanguage.Text = "Language";
            // 
            // txtMediaTmplName
            // 
            this.txtMediaTmplName.Location = new System.Drawing.Point(196, 61);
            this.txtMediaTmplName.Margin = new System.Windows.Forms.Padding(6);
            this.txtMediaTmplName.Name = "txtMediaTmplName";
            this.txtMediaTmplName.Size = new System.Drawing.Size(371, 29);
            this.txtMediaTmplName.TabIndex = 25;
            // 
            // lblTemplateName
            // 
            this.lblTemplateName.AutoSize = true;
            this.lblTemplateName.Location = new System.Drawing.Point(28, 67);
            this.lblTemplateName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTemplateName.Name = "lblTemplateName";
            this.lblTemplateName.Size = new System.Drawing.Size(146, 25);
            this.lblTemplateName.TabIndex = 24;
            this.lblTemplateName.Text = "TemplateName";
            // 
            // lblMsgText
            // 
            this.lblMsgText.AutoSize = true;
            this.lblMsgText.Location = new System.Drawing.Point(28, 235);
            this.lblMsgText.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMsgText.Name = "lblMsgText";
            this.lblMsgText.Size = new System.Drawing.Size(174, 25);
            this.lblMsgText.TabIndex = 23;
            this.lblMsgText.Text = "Parameters (CSV)";
            // 
            // btnUploadAndSendMediaUsingTemplate
            // 
            this.btnUploadAndSendMediaUsingTemplate.Location = new System.Drawing.Point(131, 277);
            this.btnUploadAndSendMediaUsingTemplate.Margin = new System.Windows.Forms.Padding(6);
            this.btnUploadAndSendMediaUsingTemplate.Name = "btnUploadAndSendMediaUsingTemplate";
            this.btnUploadAndSendMediaUsingTemplate.Size = new System.Drawing.Size(394, 42);
            this.btnUploadAndSendMediaUsingTemplate.TabIndex = 17;
            this.btnUploadAndSendMediaUsingTemplate.Text = "Upload And Send Media Using Template";
            this.btnUploadAndSendMediaUsingTemplate.UseVisualStyleBackColor = true;
            this.btnUploadAndSendMediaUsingTemplate.Click += new System.EventHandler(this.btnUploadAndSendMediaUsingTemplate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1178, 1120);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Messaging.Digital.Waba Nuget Package Demo";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtResponse;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtPhoneNoId;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtToMobileNo;
        private System.Windows.Forms.Label lblToMobileNo;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnSendTextMsg;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox rtSendTextMsgMessageText;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtUploadAndSendMediaFileName;
        private System.Windows.Forms.Button btnBrowseSendMedia;
        private System.Windows.Forms.Button btnUploadAndSendMedia;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtSendMediaTmplParms;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtUploadAndSendMediaUsingTmplFileName;
        private System.Windows.Forms.Button btnBrowseSendMediaTmpl;
        private System.Windows.Forms.TextBox txtMediaTmplLanguage;
        private System.Windows.Forms.Label lblLanguage;
        private System.Windows.Forms.TextBox txtMediaTmplName;
        private System.Windows.Forms.Label lblTemplateName;
        private System.Windows.Forms.Label lblMsgText;
        private System.Windows.Forms.Button btnUploadAndSendMediaUsingTemplate;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtSendTmplParms;
        private System.Windows.Forms.TextBox txtTmplLanguage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTmplName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSendTextTmplMsg;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button btnAuthToken;
        private System.Windows.Forms.TextBox txtAuthTokenValidityMinutes;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtUserId;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnSendMediaByUrl;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtMediaUrl;
    }
}

